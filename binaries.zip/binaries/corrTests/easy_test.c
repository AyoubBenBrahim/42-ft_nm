#include <stdio.h>
#include <stdlib.h>

int main(void) { puts("Test facile"); return (0); }
