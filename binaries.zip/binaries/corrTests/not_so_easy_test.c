
#include <stdio.h>

int a_global = 40;

int main(void) {
    printf("Global is: %d\n", a_global);
    return (0);
}